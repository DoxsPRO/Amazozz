<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Documento senza titolo</title>
</head>

<body>
	<?php
$str = "ciao";
echo md5($str);
?>
</body>
</html>